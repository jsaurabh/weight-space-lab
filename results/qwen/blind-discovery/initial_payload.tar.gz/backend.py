"""Clean VM service: base weights, training practice and numerical tools only."""
import contextlib
import copy
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import signal
import struct
import tarfile
import time
import traceback

import numpy as np
import torch

from protocol import BASE_ID, BASE_REVISION, MAX_FORWARD_CALLS, MAX_ANALYSIS_CALLS, validate_code

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results"
BASE = ROOT / "base"
SUFFIX = "\nPlease reason step by step, and put your final answer within \\boxed{}."


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def digest(tensor):
    return hashlib.sha256(tensor.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()


def extract_box(text):
    if "</think>" in text:
        text = text.split("</think>")[-1].strip()
    start, key = text.rfind("\\boxed"), "\\boxed"
    if start < 0:
        start, key = text.rfind("\\fbox"), "\\fbox"
    if start < 0:
        return None
    tail = text[start + len(key):]
    content = tail.lstrip()
    if content.startswith("{"):
        depth = 0
        for i, char in enumerate(content):
            depth += (char == "{") - (char == "}")
            if depth == 0:
                answer = content[1:i].strip()
                return answer or None
    elif key == "\\boxed" and tail.startswith(" "):
        return tail.strip().split("$")[0].split("\n")[0].strip() or None
    return None


def correct(gold, text):
    from math_verify import parse, verify
    pred = extract_box(text)
    if pred is None:
        return False
    try:
        g = parse("\\boxed{" + str(gold) + "}", parsing_timeout=5)
        p = parse("\\boxed{" + pred + "}", parsing_timeout=5)
        return bool(g and p and verify(g, p, timeout_seconds=5))
    except Exception:
        return False


class Service:
    def __init__(self):
        from huggingface_hub import snapshot_download
        torch.set_num_threads(4)
        OUT.mkdir(parents=True, exist_ok=True)
        for name in ["requests", "responses"]:
            (ROOT / name).mkdir(exist_ok=True)
        snapshot_download(BASE_ID, revision=BASE_REVISION, local_dir=BASE,
                          allow_patterns=["*.json", "*.jinja", "*.txt", "*.safetensors", "LICENSE"])
        self.mapping = json.loads((BASE / "model.safetensors.index.json").read_text())["weight_map"]
        self.headers = {}
        for shard in set(self.mapping.values()):
            with (BASE / shard).open("rb") as f:
                header_size = struct.unpack("<Q", f.read(8))[0]
                header = json.loads(f.read(header_size))
                self.headers.update({name: value for name, value in header.items() if name != "__metadata__"})
        self.config = json.loads((BASE / "config.json").read_text())
        self.practice_rows = json.loads((ROOT / "practice.json").read_text())
        self.practice_map = {r["id"]: r for r in self.practice_rows}
        self.base_cache, self.edits, self.artifacts = {}, {}, {}
        self.llm = self.hf = self.tokenizer = None
        self.engine_applied, self.hf_applied = set(), set()
        self.forward_calls = self.analysis_calls = 0
        self.frozen = False
        self.started = time.monotonic()
        self.namespace = None
        source = OUT / "source"
        source.mkdir(exist_ok=True)
        for name in ["backend.py", "protocol.py"]:
            (source / name).write_bytes((ROOT / name).read_bytes())
        write(OUT / "environment.json", {
            "model": BASE_ID, "revision": BASE_REVISION,
            "practice_count": len(self.practice_rows), "practice_sha256": hashlib.sha256((ROOT / "practice.json").read_bytes()).hexdigest(),
            "source_sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in ["backend.py", "protocol.py"]},
            "payload_contains_only_base_and_practice": True,
        })
        self.update_status("ready")

    def base_tensor(self, name):
        from safetensors import safe_open
        if name not in self.headers:
            raise ValueError("Unknown tensor name")
        if name not in self.base_cache:
            with safe_open(BASE / self.mapping[name], framework="pt", device="cpu") as source:
                self.base_cache[name] = source.get_tensor(name)
        return self.base_cache[name]

    def weight(self, name, current=False):
        tensor = self.edits.get(name) if current else None
        if tensor is None:
            tensor = self.base_tensor(name)
        return np.array(tensor.float().numpy(), copy=True)

    def save_edit(self, name, array):
        if self.frozen:
            raise ValueError("Final weights are frozen")
        if not name.startswith("model.language_model.layers.") or name not in self.headers:
            raise ValueError("Only internal text-layer tensors are editable")
        array = np.asarray(array)
        base = self.base_tensor(name)
        if list(array.shape) != list(base.shape) or array.dtype.kind not in "fiu":
            raise ValueError("Replacement must be a numeric array of the original shape")
        if not np.isfinite(array).all() or np.max(np.abs(array)) > 1e6:
            raise ValueError("Replacement contains invalid values")
        tensor = torch.from_numpy(np.array(array, dtype=np.float32, copy=True)).to(base.dtype)
        changed = int(torch.count_nonzero(tensor != base))
        if changed == 0:
            self.edits.pop(name, None)
            return {"name": name, "changed_entries": 0}
        # Reject a whole-tensor scalar gain without prohibiting local interventions.
        old = base.float().flatten().numpy()[::max(1, base.numel() // 8192)].astype(np.float64)
        new = np.asarray(array).reshape(-1)[::max(1, base.numel() // 8192)].astype(np.float64)
        norm = float(old @ old)
        if norm:
            gain = float(new @ old / norm)
            if np.linalg.norm(new - gain * old) <= 1e-6 * max(np.linalg.norm(new), 1e-20):
                raise ValueError("Whole-tensor scalar rescaling is not an admissible edit")
        candidate = dict(self.edits)
        candidate[name] = tensor.contiguous()
        if len(candidate) > 64 or sum(t.numel() for t in candidate.values()) > 160000000:
            raise ValueError("Candidate storage budget exceeded")
        self.edits = candidate
        return {"name": name, "changed_entries": changed, "edited_sha256": digest(tensor)}

    def list_edits(self):
        return [{"name": name, "shape": list(t.shape), "dtype": str(t.dtype),
                 "changed_entries": int(torch.count_nonzero(t != self.base_tensor(name))),
                 "base_sha256": digest(self.base_tensor(name)), "edited_sha256": digest(t)}
                for name, t in sorted(self.edits.items())]

    def clear_edits(self):
        if self.frozen:
            raise ValueError("Final weights are frozen")
        self.edits.clear()

    def remove_edit(self, name):
        if self.frozen:
            raise ValueError("Final weights are frozen")
        self.edits.pop(name, None)

    def checkpoint(self, label):
        from safetensors.torch import save_file
        if not re.fullmatch(r"[a-zA-Z0-9_-]{1,40}", label):
            raise ValueError("Checkpoint label must be 1–40 letters, digits, underscore or hyphen")
        path = OUT / "checkpoints" / (label + ".safetensors")
        path.parent.mkdir(exist_ok=True)
        save_file(self.edits, path)
        write(OUT / "candidate_manifests" / (label + ".json"), self.list_edits())
        return {"label": label, "edits": self.list_edits()}

    def restore(self, label):
        from safetensors.torch import load_file
        if self.frozen or not re.fullmatch(r"[a-zA-Z0-9_-]{1,40}", label):
            raise ValueError("Unavailable checkpoint operation")
        self.edits = load_file(OUT / "checkpoints" / (label + ".safetensors"), device="cpu")
        return self.list_edits()

    def get_tokenizer(self):
        if self.tokenizer is None:
            from transformers import AutoTokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(BASE, local_files_only=True)
        return self.tokenizer

    def tokenize(self, text):
        return self.get_tokenizer().encode(text, add_special_tokens=False)

    def decode(self, ids):
        return self.get_tokenizer().decode(list(map(int, ids)), skip_special_tokens=False)

    def python_analysis(self, code):
        if self.frozen or self.analysis_calls >= MAX_ANALYSIS_CALLS:
            raise ValueError("Analysis budget exhausted or weights frozen")
        validate_code(code)
        self.analysis_calls += 1
        if self.namespace is None:
            import builtins
            allowed = ["abs", "all", "any", "bool", "dict", "enumerate", "Exception", "float", "int", "isinstance",
                       "len", "list", "max", "min", "next", "print", "reversed", "round", "set", "sorted", "str",
                       "sum", "tuple", "type", "ValueError", "zip"]
            safe = {name: getattr(builtins, name) for name in allowed}

            def limited_range(*args):
                values = range(*args)
                if len(values) > 100000:
                    raise ValueError("Analysis range too large")
                return values

            def restricted_import(name, *args, **kwargs):
                if name not in {"numpy", "math"}:
                    raise ValueError("Unavailable module")
                return __import__(name, *args, **kwargs)

            safe.update(range=limited_range, __import__=restricted_import)
            self.namespace = {"__builtins__": safe, "np": np, "math": math,
                "names": sorted(self.headers), "shapes": {n: h["shape"] for n, h in self.headers.items()},
                "config": copy.deepcopy(self.config), "weight": self.weight, "save_edit": self.save_edit,
                "remove_edit": self.remove_edit, "clear_edits": self.clear_edits, "list_edits": self.list_edits,
                "checkpoint": self.checkpoint, "restore": self.restore,
                "artifact": lambda key: self.artifacts[key], "tokenize": self.tokenize, "decode": self.decode}
        output = io.StringIO()

        def timeout_handler(*args):
            raise TimeoutError("CPU analysis exceeded 120 seconds")

        previous = signal.signal(signal.SIGALRM, timeout_handler)
        signal.alarm(120)
        try:
            with contextlib.redirect_stdout(output):
                exec(compile(code, "<editor-analysis>", "exec"), self.namespace)
        finally:
            signal.alarm(0)
            signal.signal(signal.SIGALRM, previous)
        return {"stdout": output.getvalue()[:14000], "truncated": len(output.getvalue()) > 14000,
                "edits": self.list_edits()}

    def get_llm(self):
        if self.llm is None:
            from vllm import LLM
            self.update_status("initializing_generator")
            self.llm = LLM(model=str(BASE), dtype="bfloat16", max_model_len=34816,
                max_num_seqs=64, max_num_batched_tokens=8192, gpu_memory_utilization=0.70,
                enable_prefix_caching=False, seed=0, trust_remote_code=False,
                limit_mm_per_prompt={"image": 0, "video": 0})
        return self.llm

    def apply_generator(self, which):
        from safetensors.torch import save_file
        llm = self.get_llm()
        target = self.edits if which == "current" else {}
        names = set(target) | self.engine_applied
        if names:
            values = {name: target.get(name, self.base_tensor(name)) for name in names}
            path = str(ROOT / "apply.safetensors")
            save_file(values, path)

            def load(model):
                from safetensors.torch import load_file
                state = load_file(path, device="cpu")
                loaded = model.load_weights(iter(state.items()))
                return {"loaded_parameters": len(loaded)}

            applied = llm.apply_model(load)
            if any(item["loaded_parameters"] == 0 for item in applied):
                raise ValueError("Generator did not load the candidate tensors")
        self.engine_applied = set(target)

    def put_artifact(self, data, prefix):
        identifier = f"{prefix}-{len(self.artifacts) + 1:03d}"
        self.artifacts[identifier] = data
        arrays = {}

        def encode(value, key="root"):
            if isinstance(value, np.ndarray):
                arrays[key] = value
                return {"array": key, "shape": list(value.shape), "dtype": str(value.dtype)}
            if isinstance(value, dict):
                return {k: encode(v, key + "/" + k) for k, v in value.items()}
            if isinstance(value, list):
                return [encode(v, key + "/" + str(i)) for i, v in enumerate(value)]
            if isinstance(value, np.generic):
                return value.item()
            return value

        write(OUT / "artifacts" / (identifier + ".json"), encode(data))
        if arrays:
            np.savez_compressed(OUT / "artifacts" / (identifier + ".npz"), **arrays)
        return identifier

    def generate_rows(self, rows, which, max_tokens, samples=1, seed=0):
        from vllm import SamplingParams
        self.apply_generator(which)
        tokenizer = self.get_tokenizer()
        prompts = [tokenizer.apply_chat_template(
            [{"role": "user", "content": row["question"] + SUFFIX}], tokenize=False,
            add_generation_prompt=True, enable_thinking=True) for row in rows]
        started = time.perf_counter()
        outputs = self.llm.generate(prompts, SamplingParams(n=samples, temperature=0.6, top_p=0.95,
            top_k=20, presence_penalty=1.5, max_tokens=max_tokens, seed=seed), use_tqdm=True)
        records = []
        for row, request in zip(rows, outputs, strict=True):
            for sample, output in enumerate(request.outputs):
                records.append({"id": row["id"], "sample": sample, "question": row["question"],
                    "answer": row["answer"], "text": output.text, "correct": correct(row["answer"], output.text),
                    "tokens": len(output.token_ids), "hit_token_limit": output.finish_reason == "length",
                    "thinking_closed": "</think>" in output.text})
        return {"records": records, "correct": sum(r["correct"] for r in records), "total": len(records),
                "hit_token_limit": sum(r["hit_token_limit"] for r in records),
                "seconds": time.perf_counter() - started, "max_tokens": max_tokens}

    def take_pass(self):
        if self.frozen or self.forward_calls >= MAX_FORWARD_CALLS:
            raise ValueError("Forward budget exhausted or weights frozen")
        self.forward_calls += 1

    def generate(self, ids, which, max_tokens):
        if not ids or len(set(ids)) != len(ids) or any(i not in self.practice_map for i in ids):
            raise ValueError("Provide distinct valid practice IDs")
        if which not in {"base", "current", "both"} or not 1 <= max_tokens <= 32768:
            raise ValueError("Invalid generation request")
        if len(ids) * (2 if which == "both" else 1) > 32:
            raise ValueError("At most 32 total practice generations per call")
        self.take_pass()
        data, summaries = {}, {}
        for mode in (["base", "current"] if which == "both" else [which]):
            self.update_status("generating_" + mode)
            group = self.generate_rows([self.practice_map[i] for i in ids], mode, max_tokens)
            data[mode] = group["records"]
            summaries[mode] = {k: v for k, v in group.items() if k != "records"}
            summaries[mode]["examples"] = [{k: v for k, v in row.items() if k != "text"} |
                {"text_start": row["text"][:1000], "text_end": row["text"][-1500:]} for row in group["records"][:2]]
        identifier = self.put_artifact(data, "generation")
        return {"artifact": identifier, "summaries": summaries}

    def probe(self, which, texts, modules, positions):
        if which not in {"base", "current"} or not 1 <= len(texts) <= 8 or not 1 <= len(positions) <= 32 or len(modules) > 8:
            raise ValueError("Probe limits: 8 texts, 32 positions, 8 modules")
        if any(not isinstance(t, str) or len(self.tokenize(t)) > 2048 for t in texts):
            raise ValueError("Each probe text is limited to 2048 tokens")
        self.take_pass()
        from transformers import Qwen3_5ForConditionalGeneration
        if self.hf is None:
            self.update_status("initializing_probe_model")
            self.hf = Qwen3_5ForConditionalGeneration.from_pretrained(BASE, dtype=torch.bfloat16,
                attn_implementation="sdpa", local_files_only=True).requires_grad_(False).eval().to("cuda")
        target = self.edits if which == "current" else {}
        with torch.no_grad():
            for name in set(target) | self.hf_applied:
                parameter = self.hf.get_parameter(name)
                parameter.copy_(target.get(name, self.base_tensor(name)).to(parameter.device, parameter.dtype))
        self.hf_applied = set(target)
        module_map = dict(self.hf.named_modules())
        if any(name not in module_map for name in modules):
            raise ValueError("Unknown module name")
        records = []
        for text in texts:
            tokens = self.get_tokenizer()(text, return_tensors="pt").to("cuda")
            n = tokens.input_ids.shape[1]
            selected = [p if p >= 0 else n + p for p in positions]
            if not n or any(not 0 <= p < n for p in selected):
                raise ValueError("Probe position outside text")
            captured, handles = {}, []
            for name in modules:
                captured[name] = {}

                def before(module, inputs, key=name):
                    value = inputs[0]
                    if isinstance(value, torch.Tensor) and value.ndim == 3:
                        captured[key]["input"] = value[0, selected].detach().float().cpu().numpy()

                def after(module, inputs, output, key=name):
                    value = output[0] if isinstance(output, tuple) else output
                    if isinstance(value, torch.Tensor) and value.ndim == 3:
                        captured[key]["output"] = value[0, selected].detach().float().cpu().numpy()

                handles.extend([module_map[name].register_forward_pre_hook(before), module_map[name].register_forward_hook(after)])
            try:
                with torch.inference_mode():
                    output = self.hf(**tokens, output_hidden_states=True, logits_to_keep=1, use_cache=False)
                hidden = np.stack([state[0, selected].detach().float().cpu().numpy() for state in output.hidden_states])
            finally:
                for handle in handles:
                    handle.remove()
            records.append({"text": text, "tokens": tokens.input_ids[0].cpu().numpy(),
                            "positions": selected, "hidden": hidden, "modules": captured})
        identifier = self.put_artifact({"texts": records, "which": which}, "probe")
        return {"artifact": identifier, "texts": len(records), "hidden_shape": list(records[0]["hidden"].shape), "modules": modules}

    def finish(self, checkpoint_label, rationale):
        from safetensors.torch import save_file
        if self.frozen:
            return json.loads((OUT / "frozen.json").read_text())
        if checkpoint_label:
            self.restore(checkpoint_label)
        save_file(self.edits, OUT / "selected.safetensors")
        result = {"rationale": rationale, "checkpoint_label": checkpoint_label, "edits": self.list_edits(),
                  "selected_file_sha256": hashlib.sha256((OUT / "selected.safetensors").read_bytes()).hexdigest(),
                  "forward_calls": self.forward_calls, "analysis_calls": self.analysis_calls,
                  "frozen_at_unix": time.time(), "test_data_present_at_freeze": (ROOT / "sealed_test.json").exists()}
        if result["test_data_present_at_freeze"]:
            raise ValueError("Blindness violation: test data was present before freeze")
        write(OUT / "frozen.json", result)
        self.frozen = True
        return result

    def final_evaluate(self):
        if not self.frozen:
            raise ValueError("Final evaluation requires frozen weights")
        held = json.loads((ROOT / "sealed_test.json").read_text())
        write(OUT / "sealed_test.json", held)
        rows = [{"id": r["unique_id"], "question": r["problem"], "answer": r["answer"]} for r in held]
        results = {}
        for mode in ["base", "current"]:
            self.update_status("final_evaluation_" + mode)
            results[mode] = self.generate_rows(rows, mode, 32768, samples=2, seed=0)
            write(OUT / ("final_" + mode + ".json"), results[mode])
        summary = {mode: {k: v for k, v in value.items() if k != "records"} for mode, value in results.items()}
        write(OUT / "final_summary.json", summary)
        return summary

    def export(self):
        self.update_status("exporting")
        with tarfile.open("/content/qwen_blind_results.tar.gz", "w:gz") as target:
            for path in OUT.rglob("*"):
                if path.is_file() and "checkpoints" not in path.relative_to(OUT).parts:
                    target.add(path, arcname="blind-discovery/" + str(path.relative_to(OUT)))
        return {"archive": "/content/qwen_blind_results.tar.gz"}

    def update_status(self, phase):
        write(OUT / "status.json", {"phase": phase, "forward_calls": self.forward_calls,
              "analysis_calls": self.analysis_calls, "frozen": self.frozen,
              "edited_tensors": len(self.edits), "elapsed_seconds": time.monotonic() - self.started})

    def dispatch(self, name, args):
        if name == "metadata":
            return {"config": self.config, "tensors": self.headers, "practice_count": len(self.practice_rows)}
        if name == "practice":
            offset, count = args["offset"], args["count"]
            if not 0 <= offset < len(self.practice_rows) or not 1 <= count <= 8:
                raise ValueError("Practice lookup: valid offset and count 1–8")
            return self.practice_rows[offset:offset + count]
        if name == "python_analysis":
            return self.python_analysis(args["code"])
        if name == "generate":
            return self.generate(args["ids"], args["which"], args["max_tokens"])
        if name == "probe":
            return self.probe(args["which"], args["texts"], args["modules"], args["positions"])
        if name == "finish":
            return self.finish(args["checkpoint_label"], args["rationale"])
        if name == "final_evaluate":
            return self.final_evaluate()
        if name == "export":
            return self.export()
        raise ValueError("Unknown operation")

    def run(self):
        print("Clean discovery service ready", flush=True)
        while time.monotonic() - self.started < 4 * 3600:
            pending = sorted((ROOT / "requests").glob("*.json"))
            for path in pending:
                response_path = ROOT / "responses" / path.name
                if response_path.exists():
                    continue
                request = json.loads(path.read_text())
                started = time.perf_counter()
                self.update_status("tool_" + request["name"])
                try:
                    result = {"ok": True, "result": self.dispatch(request["name"], request["arguments"])}
                except Exception as exc:
                    result = {"ok": False, "error": type(exc).__name__ + ": " + str(exc)[:3000]}
                    print(traceback.format_exc(), flush=True)
                result["remaining_forward_calls"] = MAX_FORWARD_CALLS - self.forward_calls
                result["remaining_analysis_calls"] = MAX_ANALYSIS_CALLS - self.analysis_calls
                result["seconds"] = time.perf_counter() - started
                with (OUT / "tool_log.jsonl").open("a") as log:
                    log.write(json.dumps({"request": request, "response": result}) + "\n")
                write(response_path, result)
                self.update_status("frozen" if self.frozen else "waiting_for_editor")
            time.sleep(0.5)
        self.export()


if __name__ == "__main__":
    Service().run()
